/**
 * StackOverflowException class
 * @author lfk
 *
 */
public class StackOverflowException extends Exception{
	/**
	 *  Default constructor of StackOverflowException
	 * Assigns appropriate message to print in case exception happens
	 */
	StackOverflowException(){
		super("Stack is full");
	}

}
